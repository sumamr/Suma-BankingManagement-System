package com.example.demo.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Customer;
import com.example.demo.Error.CustomerNotFoundException;
import com.example.demo.Service.CustomerService;


@RestController
public class CustomerControlller {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private AccountController accountController;
	
	@PostMapping("/customer")
	public Customer createCustomer(@RequestBody Customer customer) {
		accountController.createAccount(customer.getAcctID(), 0, "Active");
		return customerService.createCustomer(customer);		
	}
	
	//get Records based on account Id
	@GetMapping("/customer/{acctID}")
	public Customer getCustomerInfo(@PathVariable int acctID) throws CustomerNotFoundException{
		return customerService.getCustomerInfo(acctID);
	}
	
	//getallRecords
	@GetMapping("/customer/")
	public List<Customer> fetctCustomerList() {
		return customerService.fetchCustomerList();
	}
	
	//Delete Records based on account Id
	@DeleteMapping("/customer/{acctID}")
	public void deleteCustomer(@PathVariable int acctID) throws CustomerNotFoundException{
		 customerService.deleteCustomer(acctID);	 
	}
	
	 //update Customer NAME
	  @PutMapping("/customer/{acctID}/name/{custName}") 
	  public int updateCustomerName(@PathVariable int acctID, @PathVariable String custName) throws CustomerNotFoundException{
		customerService.updateCustomerName(acctID,custName);
		return 0;
	  }

	  //update Customer CITY
	  @PutMapping("/customer/{acctID}/city/{city}") 
	  public int changeCustomerCity(@PathVariable int acctID, @PathVariable String city){
		customerService.updateCustomerCity(acctID,city);
		return 0;
	  }
	  
	  //update Customer STATE
	  @PutMapping("/customer/{acctID}/state/{state}") 
	  public int changeCustomerState(@PathVariable int acctID, @PathVariable String state){
		customerService.changeCustomerState(acctID,state);
		return 0;
	  }
	  
	  //update Customer COUNTRY
	  @PutMapping("/customer/{acctID}/country/{country}") 
	  public int changeCustomerCountry(@PathVariable int acctID, @PathVariable String country){
		customerService.changeCustomerCountry(acctID,country);
		return 0;
	  }
	  
	  //update Customer PASSWORD
	  @PutMapping("/customer/{acctID}/password/{password}") 
	  public int changeCustomerPassword(@PathVariable int acctID, @PathVariable String password){
		customerService.changeCustomerPassword(acctID,password);
		return 0;
	  }
	  
	  //update Customer PHONE NUMBER
	  @PutMapping("/customer/{acctID}/phone/{phoneNo}") 
	  public int changeCustomerPhoneNo(@PathVariable int acctID, @PathVariable String phoneNo){
		customerService.changeCustomerPhoneNo(acctID,phoneNo);
		return 0;
	  }

}
