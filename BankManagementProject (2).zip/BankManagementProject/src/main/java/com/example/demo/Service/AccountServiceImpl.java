package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.Entity.Accounts;
import com.example.demo.Error.AccountNotFoundException;
import com.example.demo.Repository.AccountRepository;


@Service
public class AccountServiceImpl implements AccountService {
	@Autowired
	private AccountRepository accountRepository;

	@Override
	public void createAccount(Accounts acct) {
		accountRepository.save(acct);
	}

	@Override
	public int getBalance(int acctID) throws AccountNotFoundException{
		Optional<Accounts> account =accountRepository.findById(acctID);
		if(!account.isPresent()) {
			throw new AccountNotFoundException("Account And balance Not Found");
		}
	else {
		return accountRepository.findBalanceByAcctID(acctID);
	}

	}

	@Override
	public void depositAmount(int acctID, int amount) {
		accountRepository.saveBalanceByAcctID(acctID, amount);
		
	}

	@Override
	public void withdrawAmount(int acctID, int amount) {

		accountRepository.withdrawAmountByAcctID(acctID, amount);
	}

	@Override
	public void transferAmount(int acctID, int destAcctID, int amount) {
		accountRepository.withdrawAmountByAcctID(acctID, amount);
		accountRepository.saveBalanceByAcctID(destAcctID, amount);	
	}
	

	@Override
	public void deleteAccount(int acctID) throws AccountNotFoundException{
		Optional<Accounts> account =accountRepository.findById(acctID);
		if(!account.isPresent()) {
			throw new AccountNotFoundException("Account is Not Available");
		}
	else {
		accountRepository.deleteById(acctID);
	}
		
	}

	@Override
	public Accounts getAccountInfo(int acctID) throws AccountNotFoundException{
		Optional<Accounts> account =accountRepository.findById(acctID);
		if(!account.isPresent()) {
			throw new AccountNotFoundException("Account Does Not Exist");
		}
		else {
		return accountRepository.findById(acctID).orElse(null);
		}
		
	}

	@Override
	public List<Accounts> fetchAccountList() {
		return accountRepository.findAll();
	}


}
